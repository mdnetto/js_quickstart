$(function(){
	$("#slides").slidesjs({
		navigation: {
			active: false,
			effect: "fade"
		},
		pagination: {
			effect: "fade"
		},
		effect: {
			fade: {
				speed: 800
			}
		}
	});
});
