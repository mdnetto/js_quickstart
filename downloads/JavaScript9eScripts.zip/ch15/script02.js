$(document).ready(function() {
	$("#theMenu").accordion({
		animate: false,
		collapsible: true,
		header: ".menuLink",
		heightStyle: "content"
	});
});
