if (confirm("Are you sure you want to do that?")) {
	alert("You said yes");
}
else {
	alert("You said no");
}
