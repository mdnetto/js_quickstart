window.onbeforeunload = function() {
	return "If you close this window, your flight choices will be lost!";
}
